<?php
require_once 'conexao.php';

$mensagem = "";
$servico_editar = null; // Guarda os dados do serviço a ser editado

// --- 1. AÇÃO: EXCLUIR SERVIÇO (DELETE) ---
if (isset($_GET['acao']) && $_GET['acao'] === 'excluir' && !empty($_GET['id'])) {
    $id_excluir = (int)$_GET['id'];
    try {
        $stmtDelete = $pdo->prepare("DELETE FROM tb_servico WHERE id_servico = ?");
        $stmtDelete->execute([$id_excluir]);
        $mensagem = "<div class='alerta sucesso'>Serviço #{$id_excluir} removido com sucesso!</div>";
    } catch (PDOException $e) {
        $mensagem = "<div class='alerta erro'>Não é possível excluir este serviço pois ele está vinculado a agendamentos existentes!</div>";
    }
}

// --- 2. CARREGAR DADOS PARA EDIÇÃO (GET) ---
if (isset($_GET['acao']) && $_GET['acao'] === 'editar' && !empty($_GET['id'])) {
    $id_editar = (int)$_GET['id'];
    $stmtEdit = $pdo->prepare("SELECT * FROM tb_servico WHERE id_servico = ?");
    $stmtEdit->execute([$id_editar]);
    $servico_editar = $stmtEdit->fetch();
}

// --- 3. AÇÃO: SALVAR CADASTRO OU EDIÇÃO (INSERT OU UPDATE) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_servico = $_POST['id_servico'] ?? '';
    $nome_servico = trim($_POST['nome_servico'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $preco = $_POST['preco'] ?? '';
    $duracao_minutos = $_POST['duracao_minutos'] ?? 30;

    if (!empty($nome_servico) && !empty($preco)) {
        try {
            if (!empty($id_servico)) {
                // EDIÇÃO (UPDATE)
                $stmt = $pdo->prepare("UPDATE tb_servico SET nome_servico = ?, descricao = ?, preco = ?, duracao_minutos = ? WHERE id_servico = ?");
                $stmt->execute([$nome_servico, $descricao, $preco, $duracao_minutos, $id_servico]);
                $mensagem = "<div class='alerta sucesso'>Serviço #{$id_servico} atualizado com sucesso!</div>";
                $servico_editar = null; // Limpa o modo de edição
            } else {
                // CADASTRO (INSERT)
                $stmt = $pdo->prepare("INSERT INTO tb_servico (nome_servico, descricao, preco, duracao_minutos) VALUES (?, ?, ?, ?)");
                $stmt->execute([$nome_servico, $descricao, $preco, $duracao_minutos]);
                $mensagem = "<div class='alerta sucesso'>Serviço cadastrado com sucesso!</div>";
            }
        } catch (PDOException $e) {
            $mensagem = "<div class='alerta erro'>Erro ao salvar serviço: " . $e->getMessage() . "</div>";
        }
    } else {
        $mensagem = "<div class='alerta erro'>Preencha o Nome e o Preço do serviço!</div>";
    }
}

// Consulta de Serviços
$servicos = $pdo->query("SELECT * FROM tb_servico ORDER BY id_servico DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Serviços Oferecidos - Salão</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <a href="index.php" class="btn-voltar">← Voltar ao Menu</a>
    <h1>Serviços Oferecidos</h1>

    <?= $mensagem ?>

    <!-- Formulário de Cadastro / Edição -->
    <div class="card-formulario">
        <h2><?= $servico_editar ? "✏️ Editar Serviço #{$servico_editar['id_servico']}" : "Adicionar Novo Serviço" ?></h2>
        
        <form method="POST" action="servicos.php" class="form-grid">
            <!-- Campo oculto com o ID quando for edição -->
            <input type="hidden" name="id_servico" value="<?= $servico_editar['id_servico'] ?? '' ?>">

            <div class="campo">
                <label>Nome do Serviço:</label>
                <input type="text" name="nome_servico" placeholder="Ex: Penteado de Festa" value="<?= htmlspecialchars($servico_editar['nome_servico'] ?? '') ?>" required>
            </div>

            <div class="campo">
                <label>Preço (R$):</label>
                <input type="number" step="0.01" name="preco" placeholder="150.00" value="<?= htmlspecialchars($servico_editar['preco'] ?? '') ?>" required>
            </div>

            <div class="campo">
                <label>Duração (Minutos):</label>
                <input type="number" name="duracao_minutos" value="<?= htmlspecialchars($servico_editar['duracao_minutos'] ?? '45') ?>" required>
            </div>

            <div class="campo">
                <label>Descrição:</label>
                <input type="text" name="descricao" placeholder="Breve descrição do tratamento" value="<?= htmlspecialchars($servico_editar['descricao'] ?? '') ?>">
            </div>

            <div style="display: flex; gap: 10px; align-items: flex-end;">
                <button type="submit" class="btn-salvar">
                    <?= $servico_editar ? "💾 Salvar Alterações" : "➕ Cadastrar Serviço" ?>
                </button>

                <?php if ($servico_editar): ?>
                    <a href="servicos.php" class="btn-voltar" style="margin-bottom: 0; padding: 10px;">Cancelar</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Tabela de Listagem -->
    <div class="secao-tabela">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Serviço</th>
                    <th>Descrição</th>
                    <th>Duração</th>
                    <th>Preço</th>
                    <th style="text-align: center;">Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($servicos) > 0): ?>
                    <?php foreach ($servicos as $serv): ?>
                        <tr>
                            <td><?= $serv['id_servico'] ?></td>
                            <td><?= htmlspecialchars($serv['nome_servico']) ?></td>
                            <td><?= htmlspecialchars($serv['descricao'] ?? '-') ?></td>
                            <td><?= $serv['duracao_minutos'] ?> min</td>
                            <td>R$ <?= number_format($serv['preco'], 2, ',', '.') ?></td>
                            <td style="text-align: center; white-space: nowrap;">
                                <a href="servicos.php?acao=editar&id=<?= $serv['id_servico'] ?>" 
                                   class="btn-editar">
                                    ✏️ Editar
                                </a>

                                <a href="servicos.php?acao=excluir&id=<?= $serv['id_servico'] ?>" 
                                   class="btn-excluir" 
                                   onclick="return confirm('Deseja realmente remover este serviço?')">
                                    🗑️ Apagar
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" style="text-align: center;">Nenhum serviço encontrado.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>