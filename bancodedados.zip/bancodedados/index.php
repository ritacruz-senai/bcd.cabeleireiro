<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Salão de Cabeleireiro</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h1>Gestão do Salão de Cabeleireiro</h1>
    <p class="subtitulo">Selecione uma das opções abaixo para gerir o sistema:</p>

    <!-- Menu Principal / Navegação do Site -->
    <div class="menu-cards">
        <a href="agendamentos.php" class="card-link">
            <h2>📅 Agendamentos</h2>
            <p>Visualizar e gerir todos os agendamentos marcados.</p>
        </a>

        <a href="clientes.php" class="card-link">
            <h2>👥 Clientes</h2>
            <p>Lista de clientes cadastrados e informações de contacto.</p>
        </a>

        <a href="servicos.php" class="card-link">
            <h2>✂️ Serviços</h2>
            <p>Consulte a lista de serviços, durações e preços.</p>
        </a>
    </div>
</div>

</body>
</html>