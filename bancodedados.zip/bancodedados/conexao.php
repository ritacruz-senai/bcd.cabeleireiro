<?php
$host = 'localhost';
$db   = 'db_cabeleireiro';
$user = 'root'; // Altere se o usuário do seu MySQL for diferente
$pass = '12345678';     // Coloque a sua senha do MySQL aqui

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
  
} catch (PDOException $e) {
    die("Erro na conexão com o banco de dados: " . $e->getMessage());
}