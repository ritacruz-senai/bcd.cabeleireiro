<?php
require_once 'conexao.php';

$mensagem = "";

// --- 1. AÇÃO: EXCLUIR CLIENTE (DELETE) ---
if (isset($_GET['acao']) && $_GET['acao'] === 'excluir' && !empty($_GET['id'])) {
    $id_excluir = (int)$_GET['id'];
    try {
        $stmtDelete = $pdo->prepare("DELETE FROM tb_cliente WHERE id_cliente = ?");
        $stmtDelete->execute([$id_excluir]);
        $mensagem = "<div class='alerta sucesso'>Cliente #{$id_excluir} removido com sucesso!</div>";
    } catch (PDOException $e) {
        // Impede a exclusão se o cliente tiver agendamentos registrados no banco
        $mensagem = "<div class='alerta erro'>Não é possível descadastrar este cliente pois ele possui agendamentos vinculados!</div>";
    }
}

// --- 2. AÇÃO: CADASTRAR CLIENTE (INSERT) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $data_nascimento = $_POST['data_nascimento'] ?? null;

    if (!empty($nome) && !empty($telefone)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO tb_cliente (nome, telefone, email, data_nascimento) VALUES (?, ?, ?, ?)");
            $stmt->execute([$nome, $telefone, $email ?: null, $data_nascimento ?: null]);
            $mensagem = "<div class='alerta sucesso'>Cliente cadastrado com sucesso!</div>";
        } catch (PDOException $e) {
            $mensagem = "<div class='alerta erro'>Erro ao cadastrar cliente (e-mail já pode estar cadastrado).</div>";
        }
    } else {
        $mensagem = "<div class='alerta erro'>Preencha os campos obrigatórios (Nome e Telefone)!</div>";
    }
}

// Consulta de Clientes
$clientes = $pdo->query("SELECT * FROM tb_cliente ORDER BY id_cliente DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes Cadastrados - Salão</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <a href="index.php" class="btn-voltar">← Voltar ao Menu</a>
    <h1>Clientes Cadastrados</h1>

    <?= $mensagem ?>

    <!-- Formulário de Cadastro -->
    <div class="card-formulario">
        <h2>Adicionar Novo Cliente</h2>
        <form method="POST" action="clientes.php" class="form-grid">
            <div class="campo">
                <label>Nome Completo:</label>
                <input type="text" name="nome" placeholder="Ex: Maria Souza" required>
            </div>

            <div class="campo">
                <label>Telefone:</label>
                <input type="text" name="telefone" placeholder="(19) 99999-8888" required>
            </div>

            <div class="campo">
                <label>E-mail:</label>
                <input type="email" name="email" placeholder="cliente@email.com">
            </div>

            <div class="campo">
                <label>Data de Nascimento:</label>
                <input type="date" name="data_nascimento">
            </div>

            <button type="submit" class="btn-salvar">➕ Cadastrar Cliente</button>
        </form>
    </div>

    <!-- Tabela de Listagem -->
    <div class="secao-tabela">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nome</th>
                    <th>Telefone</th>
                    <th>E-mail</th>
                    <th>Data de Nascimento</th>
                    <th style="text-align: center;">Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($clientes) > 0): ?>
                    <?php foreach ($clientes as $cli): ?>
                        <tr>
                            <td><?= $cli['id_cliente'] ?></td>
                            <td><?= htmlspecialchars($cli['nome']) ?></td>
                            <td><?= htmlspecialchars($cli['telefone']) ?></td>
                            <td><?= htmlspecialchars($cli['email'] ?? '-') ?></td>
                            <td><?= $cli['data_nascimento'] ? date('d/m/Y', strtotime($cli['data_nascimento'])) : '-' ?></td>
                            <td style="text-align: center;">
                                <a href="clientes.php?acao=excluir&id=<?= $cli['id_cliente'] ?>" 
                                   class="btn-excluir" 
                                   onclick="return confirm('Deseja realmente descadastrar este cliente?')">
                                    🗑️ Apagar
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" style="text-align: center;">Nenhum cliente encontrado.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>