<?php
require_once 'conexao.php';

$mensagem = "";

// --- 1. AÇÃO: EXCLUIR AGENDAMENTO (DELETE) ---
if (isset($_GET['acao']) && $_GET['acao'] === 'excluir' && !empty($_GET['id'])) {
    $id_excluir = (int)$_GET['id'];
    try {
        $stmtDelete = $pdo->prepare("DELETE FROM tb_agendamento WHERE id_agendamento = ?");
        $stmtDelete->execute([$id_excluir]);
        $mensagem = "<div class='alerta sucesso'>Agendamento #{$id_excluir} removido com sucesso!</div>";
    } catch (PDOException $e) {
        $mensagem = "<div class='alerta erro'>Erro ao excluir agendamento: " . $e->getMessage() . "</div>";
    }
}

// --- 2. AÇÃO: CADASTRAR AGENDAMENTO (INSERT) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_cliente = $_POST['id_cliente'] ?? '';
    $id_profissional = $_POST['id_profissional'] ?? '';
    $id_servico = $_POST['id_servico'] ?? '';
    $data_hora = $_POST['data_hora'] ?? '';

    if (!empty($id_cliente) && !empty($id_profissional) && !empty($id_servico) && !empty($data_hora)) {
        try {
            $stmtInsert = $pdo->prepare("INSERT INTO tb_agendamento (id_cliente, id_profissional, id_servico, data_hora, status) VALUES (?, ?, ?, ?, 'Agendado')");
            $stmtInsert->execute([$id_cliente, $id_profissional, $id_servico, $data_hora]);
            $mensagem = "<div class='alerta sucesso'>Agendamento cadastrado com sucesso!</div>";
        } catch (PDOException $e) {
            $mensagem = "<div class='alerta erro'>Erro ao agendar: " . $e->getMessage() . "</div>";
        }
    } else {
        $mensagem = "<div class='alerta erro'>Preencha todos os campos obrigatórios!</div>";
    }
}

// Consultas para preencher a tabela e os selects
$agendamentos = $pdo->query("
    SELECT a.id_agendamento, a.data_hora, a.status, c.nome AS cliente, p.nome AS profissional, s.nome_servico AS servico, s.preco
    FROM tb_agendamento a
    INNER JOIN tb_cliente c ON a.id_cliente = c.id_cliente
    INNER JOIN tb_profissional p ON a.id_profissional = p.id_profissional
    INNER JOIN tb_servico s ON a.id_servico = s.id_servico
    ORDER BY a.data_hora ASC
")->fetchAll();

$clientes = $pdo->query("SELECT id_cliente, nome FROM tb_cliente")->fetchAll();
$profissionais = $pdo->query("SELECT id_profissional, nome FROM tb_profissional")->fetchAll();
$servicos = $pdo->query("SELECT id_servico, nome_servico FROM tb_servico")->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamentos - Salão</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <a href="index.php" class="btn-voltar">← Voltar ao Menu</a>
    <h1>Agendamentos</h1>

    <?= $mensagem ?>

    <!-- Formulário de Cadastro -->
    <div class="card-formulario">
        <h2>Novo Agendamento</h2>
        <form method="POST" action="agendamentos.php" class="form-grid">
            <div class="campo">
                <label>Cliente:</label>
                <select name="id_cliente" required>
                    <option value="">Selecione o Cliente</option>
                    <?php foreach ($clientes as $c): ?>
                        <option value="<?= $c['id_cliente'] ?>"><?= htmlspecialchars($c['nome']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="campo">
                <label>Profissional:</label>
                <select name="id_profissional" required>
                    <option value="">Selecione o Profissional</option>
                    <?php foreach ($profissionais as $p): ?>
                        <option value="<?= $p['id_profissional'] ?>"><?= htmlspecialchars($p['nome']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="campo">
                <label>Serviço:</label>
                <select name="id_servico" required>
                    <option value="">Selecione o Serviço</option>
                    <?php foreach ($servicos as $s): ?>
                        <option value="<?= $s['id_servico'] ?>"><?= htmlspecialchars($s['nome_servico']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="campo">
                <label>Data e Hora:</label>
                <input type="datetime-local" name="data_hora" required>
            </div>

            <button type="submit" class="btn-salvar">➕ Confirmar Agendamento</button>
        </form>
    </div>

    <!-- Tabela de Listagem -->
    <div class="secao-tabela">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Data e Hora</th>
                    <th>Cliente</th>
                    <th>Profissional</th>
                    <th>Serviço</th>
                    <th>Valor</th>
                    <th>Status</th>
                    <th style="text-align: center;">Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($agendamentos) > 0): ?>
                    <?php foreach ($agendamentos as $row): ?>
                        <tr>
                            <td><?= $row['id_agendamento'] ?></td>
                            <td><?= date('d/m/Y H:i', strtotime($row['data_hora'])) ?></td>
                            <td><?= htmlspecialchars($row['cliente']) ?></td>
                            <td><?= htmlspecialchars($row['profissional']) ?></td>
                            <td><?= htmlspecialchars($row['servico']) ?></td>
                            <td>R$ <?= number_format($row['preco'], 2, ',', '.') ?></td>
                            <td>
                                <?php
                                    $classeStatus = 'status-agendado';
                                    if ($row['status'] === 'Concluído') $classeStatus = 'status-concluido';
                                    if ($row['status'] === 'Cancelado') $classeStatus = 'status-cancelado';
                                ?>
                                <span class="status <?= $classeStatus ?>"><?= $row['status'] ?></span>
                            </td>
                            <td class="acoes-coluna" style="text-align: center;">
                                <a href="agendamentos.php?acao=excluir&id=<?= $row['id_agendamento'] ?>" 
                                   class="btn-excluir" 
                                   onclick="return confirm('Deseja realmente EXCLUIR este registro permanentemente?')">
                                    🗑️ Apagar
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" style="text-align: center;">Nenhum agendamento encontrado.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>